<?php

class Application_Model_DbTable_Illnesstype extends Zend_Db_Table_Abstract {
               protected $_name = "illnesstype";               
}

?>
