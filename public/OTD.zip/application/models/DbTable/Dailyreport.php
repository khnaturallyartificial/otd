<?php

class Application_Model_DbTable_Dailyreport extends Zend_Db_Table_Abstract {
               protected $_name = 'dailyreport';

               function insertdata($data){
                              try{
                              $this->insert($data);
                              return "success";
                              }
                              catch(Exception $e){
                                             return 'failed';
                              }
               }

               function selectlastentry($aid){
                   $select = $this->_db->select()->from($this->_name)
                           ->where("userid = ?", $aid)
                           ->limit(1)
                           ->order("date DESC");
                   return $this->_db->fetchAll($select);
               }

               function fetchAllForUser($userid){
                              $select = $this->_db->select()->from($this->_name)->where("userid = ?", $userid)
                                      ->order('date ASC')->limit(30);
                              $result = $this->_db->fetchAll($select);
                              return $result;
               }

               function alreadyDoneToday($userid){
                              $today = date("Y-m-d", time());
                              $select = $this->_db->select()->from($this->_name)
                                      ->where("userid = ?",$userid)->where("date = ?",$today);
                              $result = $this->_db->fetchAll($select);
                              if(count($result)>0){
                                             return true;
                              }
                              else{
                                             return false;
                              }
               }
}

?>
