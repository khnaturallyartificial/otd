<?php

class Application_Model_DbTable_Alerts extends Zend_Db_Table_Abstract {
               protected $_name = "alerts";
               protected $_primary = "alertid";

               function doAlert($alerthead,$alertcontent, $alertlevel,$athleteid,$smail=false){
                              $data = array(
                                  "alertlevel" => $alertlevel,
                                  "alerthead" => $alerthead,
                                  "alertcontent" => $alertcontent,
                                  "athleteid" => $athleteid
                              );
                              $this->_db->insert($this->_name,$data);
                              
                              if($smail == true){
                                             $user = new Application_Model_DbTable_User();
                                             $cav = new Application_Model_DbTable_Coachathleteview();
                                             $athrow = $cav->getCoachId($athleteid);
                                             $coachid = $athrow;
                                             $athrow = $user->fetchRow("userid = ".$coachid);
                                             $coachmail = $athrow["email"];
                                             $athrow = $user->fetchRow("userid = ".$athleteid);
                                             $athname = $athrow["name"]. " " . $athrow["surname"];
                                             $mail = new Zend_Mail();
                                             $mail->setBodyHtml($alertcontent . '<br/><img src="http://otd.naturallyartificial.net/img/smallwcl.gif" alt=""/>');
                                             $mail ->setFrom("system@otd.com", "OTD system Message");
                                             $mail->addTo($coachmail, $coachmail);
                                             $mail->setSubject($alerthead ." : ". $athname);
                                             $mail->send();
                              }

               }
}

?>
