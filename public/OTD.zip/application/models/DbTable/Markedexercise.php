<?php
class Application_Model_DbTable_Markedexercise extends Zend_Db_Table_Abstract{
	protected $_name = "markedexercise";
	 
	function markExercisePlan($exerciseplanid,$mode,$userid=0,$actuallifted="",$actualreps="",$weight=""){
		$done = ($mode == "done") ? "1" : "0";
                                        $date = date("Y-m-d",time());
                                       
		$sql = "INSERT INTO `".$this->_name."` VALUES (".$exerciseplanid.", ".$done.",".$userid.",'".$date."',".$actuallifted.",".$actualreps.",".$weight.") ON DUPLICATE KEY UPDATE `date` = '".$date."', `done` = ".$done.",
`actual_total_lifted` = ".$actuallifted.", `actual_total_reps` = ".$actualreps.", `actual_weight` = ".$weight;
                                        $result = $this->_db->query($sql);
                                        if($result){return true;}else{return false;}				
	}
}
?>