<?php

class Application_Model_DbTable_Exercise extends Zend_Db_Table_Abstract{
               protected $_name = "exercise";
               public function getAllExercise(){
                               $select = $this->_db->select()->from($this->_name);
                              $result = $this->_db->fetchAll($select);
                              $content = array();
                              foreach($result as $r){
                                             $content[$r["exerciseid"]] = $r["exercisename"];
                              }
                              return $content;
               }
               public function makeExerciseSelection(){
                              $select = $this->_db->select()->from($this->_name);
                              $result = $this->_db->fetchAll($select);
                              $ret = array();
                              foreach($result as $r){
                                             $ret[$r["exerciseid"]] = $r["exerciseid"]." - ".$r["exercisename"];
                              }
                              return $ret;
               }
               public function makeExerciseList(){
                              $select = $this->_db->select()->from($this->_name)->order('exercisename ASC');
                              $result = $this->_db->fetchAll($select);
                              $this->_db->closeConnection();
                              $data = "<ul>";
                              foreach($result as $r){
                                             $data .= '     <li>'.$r["exercisename"].'</li>
                                                            ';
                              }
                              $data .= '</ul>';
                              return $data;
               }

               public function addExercise($en){
                              $validator = new Zend_validate_Regex('/^[a-zA-Z0-9\s\.\-\(\)]{1,50}$/');
                              if($validator->isValid($en)){
                                             $data = array("exercisename" => $en);
                                             if($this->insert($data)){
                                                            return "`$en` added to the list";
                                             }
                                             else{
                                                            return "Failed to insert data";
                                             }
                              }
                              else{
                                             return "Invalid Character. Alphabets, numbers, spaces, dot and brackets allowed";
                              }
               }
}

?>
