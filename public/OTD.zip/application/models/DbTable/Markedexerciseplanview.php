<?php
class Application_Model_DbTable_Markedexerciseplanview extends Zend_Db_Table_Abstract{
	protected $_name = "markedexerciseplanview";
	
	function getMarkedExerciseInPlan($planid){
                                   $auth = Zend_Auth::getInstance();
                                   $user = $auth->getIdentity();
		$select	= $this->_db->select()->from($this->_name, array("exerciseplanid", "done"))
		->where("planid = ?", (int) $planid)
                                        ->where("userid = ?", $user->userid);
		$result = $this->_db->fetchAll($select);
		$ding = array();
		$ref = array("skipped","done");
	                   foreach($result as $l){
	                   	$ding[$l["exerciseplanid"]] = $ref[$l["done"]];
	                   }
		return $ding;
	}

                    function getAvLoadRepsPercent30days($userid){
                                   $today = date("Y-m-d", time());
                                   $lastmonth = date("Y-m-d", time90 - 2592000 );
                                   $select = $this->_db->query("select SUM(`pres_total_lifted`) as `sptl`, SUM(`actual_total_lifted`) as `satl`,
                                                  SUM(`pres_reps`) as `spr`, SUM(`actual_total_reps`) as `satr` from `markedexerciseplanview` where
                                                  `userid` = '".$userid."' and `date` between '".$lastmonth."' and '".$today."'");
                                   $result = $select->fetchAll();

                                   $satl = (int)  $result[0]["satl"];
                                   $sptl = (int) $result[0]["sptl"];

                                   $satr = (int) $result[0]["satr"];
                                   $spr = (int) $result[0]["spr"];

                                   $load = @round($satl / $sptl * 100);
                                   $reps = @round($satr / $spr * 100);
                                   return array($load,$reps);

                    }
}

?>