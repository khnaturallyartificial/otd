<?php
class Application_Model_DbTable_Coach extends Zend_Db_Table_Abstract{
               static function makeAthleteMenu(){
                              $data = array();
                              $data[] = array(
			'title' => 'Dashboard',
			'img' => '/img/dashboard.png',
			'link' => '/',
			'tooltip' => 'Dashboard - View everything at a glance'
			) ;
                              $data[] = array(
			'title' => 'Injuries and niggles',
			'img' => '/img/bandaid.png',
			'link' => '/athlete/injuries',
			'tooltip' => 'If you have any injuries or niggles, please report them here'
			) ;
                              $data[] = array(
			'title' => 'Illness & Injuries history',
			'img' => '/img/envelope.png',
			'link' => '/athlete/history',
			'tooltip' => 'The last 50 illness/injuries reports.'
			) ;
                               $data[] = array(
			'title' => 'My Progress',
			'img' => '/img/progress.png',
			'link' => '/athlete/myprogress',
			'tooltip' => 'Fill in the daily report here. Please try to do this everyday.'
			) ;
                               $data[] = array(
			'title' => 'My Info.',
			'img' => '/img/info.png',
			'link' => '/athlete/profile',
			'tooltip'=>'View alert (Athlete\'s incompleted exercises, high tiredness, etc.)'
			) ;

                                


                              $menu = Application_Model_Misc::makeMenu('accordiontitle','accordionitems',$data);
                              return $menu;

               }


    static function makeCoachMenu(){
	$data = array();
	$data[] = array(
			'title' => 'Dashboard',
			'img' => '/img/dashboard.png',
			'link' => '/',
			'tooltip' => 'Dashboard - View everything at a glance'
			) ;
	$data[] = array(
			'title' => 'Plans',
			'img' => '/img/plans.png',
			'link' => '/',
			'tooltip' => 'Manage exercise plans',
			'menuitems' => array(
				array('text' => 'View/Edit plans', 'link' =>'/coach/plans','tooltip'=>'View existing plans and make modifications'),
				array('text' => 'Create new plan', 'link' =>'/coach/createplan','tooltip'=>'Create a new (blank) plan.'),
				array('text' => 'Exercise types', 'link' =>'/coach/exercise','tooltip'=>'View/Add exercise types')
							)
			) ;
	$data[] = array(
			'title' => 'Athletes',
			'img' => '/img/athletes.png',
			'link' => '/',
			'tooltip' => 'Manage athletes currently training under you',
			'menuitems' => array(
				 array('text' => 'View athletes', 'link' =>'/coach/viewath','tooltip'=>'A list of all athletes training under you.'),
                                                                                 array('text' => 'Athlete Summary', 'link' =>'/coach/athsum','tooltip'=>'Detailed information about athletes.'),
                                                                                 array('text' => 'Injuries History', 'link' =>'/coach/history','tooltip'=>'Athlete\'s injuries and illness history')
					)
			) ;
	
	/*$data[] = array(
			'title' => 'Messages',
			'img' => '/img/mail.png',
			'link' => '/',
			'tooltip' => 'Send and recieve messages to athletes and other coaches',
			'menuitems' => array(
							    array('text' => 'Compose Message', 'link' =>'www.ex.com', 'tooltip'=>'Compose a new message'),
							    array('text' => 'Inbox', 'link' =>'www.ex.com', 'tooltip'=>'View recieved messages'),
							    array('text' => 'Sent', 'link' =>'www.ex.com', 'tooltip'=>'View sent messages'),
							    array('text' => 'View Contacts', 'link' =>'www.ex.com', 'tooltip'=>'A list of your contacts.')
							)
			) ;*/
	$data[] = array(
			'title' => 'Monitor',
			'img' => '/img/monitor.png',
			'link' => '/',
			'tooltip'=>'Monitor the performance of your athletes',
			'menuitems' => array(
							    array('text' => 'Athlete analysis', 'link' =>'/coach/monitor', 'tooltip'=>'Analysis graphs for your athletes.')/*,
							    array('text' => 'Squad Analysis', 'link' =>'www.ex.com', 'tooltip'=>'Squad training performance')*/
							)
			) ;
	$data[] = array(
			'title' => 'Alert',
			'img' => '/img/alerts.png',
			'link' => '/coach/alert',
			'tooltip'=>'View alert (Athlete\'s incompleted exercises, high tiredness, etc.)'
			) ;
                    $data[] = array(
			'title' => 'My Info.',
			'img' => '/img/info.png',
			'link' => '/coach/profile',
			'tooltip'=>'View alert (Athlete\'s incompleted exercises, high tiredness, etc.)'
			) ;
	$menu = Application_Model_Misc::makeMenu('accordiontitle','accordionitems',$data);
	return $menu;
    }
}
?>