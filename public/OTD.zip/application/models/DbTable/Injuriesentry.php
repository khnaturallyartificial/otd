<?php

class Application_Model_DbTable_Injuriesentry extends Zend_Db_Table_Abstract {
               protected $_name = "injuries_entry";
}

?>
