<?php

class AthleteController extends Zend_Controller_Action{
               protected $user = null;
               function init(){
                              $auth = Zend_Auth::getInstance();
                              if($auth->hasIdentity()){
                                             $user = $auth->getIdentity();
                                             if($user->role != "A"){
                                                            $this->_helper->redirector('index','index');
                                             }
                                             else{
                                                            $this->user = $user;
                                             }
                              }
                              else{
                              	$this->_helper->redirector('index','index');
                              }
                              $this->view->headScript()->appendFile('http://ajax.googleapis.com/ajax/libs/jquery/1.4.2/jquery.min.js');
                    $this->view->headScript()->appendFile('/js/jqueryUI.js');
	$this->view->headScript()->appendFile('/js/roundcorner.js');
	$this->view->headScript()->appendFile('/js/script.js');
	$this->view->headScript()->appendFile('/js/athlete.js');
                    $this->view->headLink()->appendStylesheet('/css/jqueryUI.css');

                    $this->view->menu = Application_Model_DbTable_Coach::makeAthleteMenu();

               }
               
               
               function indexAction(){
                              $this->view->headTitle("Dashboard [Athlete]");
                              
                              $ep = new Application_Model_DbTable_Exerciseplan();
                              $this->view->todotoday = $ep->makeExercisePlansToday($this->user->planid,null,true);
                              $this->view->todoyesterday = $ep->makeExercisePlansToday($this->user->planid,time() - 86400,true);
                              if(true){ //replace true with date("N",time()) ==1 for every monday
                                             $today = date("Y-m-d", strtotime(date("Y",time())  . "W"  . date("W",time())));;
                                             $wrr = new Application_Model_DbTable_WeeklyReportRatio();
                                            $already = count($wrr->fetchAll("`userid` = '".$this->user->userid."' and`date` = '".$today."'"));
                                             if($already == 0){
                                                            $this->view->weeklyalert = true;
                                             }
                                             else{
                                                            $this->view->weeklyalert = false;
                                             }
                              }

                              $dr = new Application_Model_DbTable_Dailyreport();
                              $already = count($dr->fetchAll("`userid` = '".$this->user->userid."' and `date` = '".date("Y-m-d", time()) ."'"));
                              if(!$already){
                                             $this->view->dailyalert = true;
                              }
               }
               
               function markexerciseplanAction(){
               	$this->_helper->layout->disableLayout();
               	$this->_helper->viewRenderer->setNoRender(true);
               		if($this->getRequest()->isPost()){
               			$data = $this->getRequest()->getPost();
               			$me = new Application_Model_DbTable_Markedexercise();
                                                            $result=$me->markExercisePlan($data["exid"],$data["mode"],$this->user->userid,$data["actual_total_lifted"],$data["actual_total_reps"],$data["actual_weight"]);
               			if($result == true){
                                                                           echo "success";
                                                            }
                                                            else{
                                                                           echo "Failed to mark exercise. Please contact Administrator";
                                                            }

               		}
               }

               function dailyreportAction (){
                              $wr = new Application_Model_DbTable_WeeklyReport();
                              $result = $wr->alreadyDoneThisWeek($this->user->userid);
                              if($result == false){
                                             $session = new Zend_Session_Namespace("System");
                                             $session->msg = "You have not completed the weekly illness report, please do that first.";
                                             $session->redir = "/athlete/illness";
                                             $session->redirtext = "Take me to weekly illness form.";
                                             $this->_helper->redirector("index", "message");
                              }
                              $dr = new Application_Model_DbTable_Dailyreport();
                              $result = $dr->alreadyDoneToday($this->user->userid);
                              if($result == true){
                                             $session = new Zend_Session_Namespace("System");
                                             $session->msg = "You have already completed the daily report
                                                            <br/>If you have any injuries and/or niggles, please click on the link below.";
                                             $session->redir = "/athlete/injuries";
                                             $session->redirtext = "Take me to injury & niggle form";
                                             $this->_helper->redirector("index", "message");
                              }
                              $this->view->headTitle('Daily Report');
                              $this->view->headLink()->appendStylesheet('/css/dailyreport.css');
                              $this->view->form = new Application_Form_DailyReportForm();
                              $dr = new Application_Model_DbTable_Dailyreport();
                              $ath = $dr->selectlastentry($this->user->userid);
                              $dat = array(
                                "bw_morning"=>$ath[0]["bw_morning"],
                                  "bw_evening"=>$ath[0]["bw_evening"]
                              );
                              $this->view->form->populate($dat);

                              if($this->getRequest()->isPost()){
                                             $data = $this->GetRequest()->getPost();
                                             if($this->view->form->isValid($data)){
                                                            $dr = new Application_Model_DbTable_Dailyreport();
                                                            $data["userid"] = $this->user->userid;
                                                            $result = $dr->insertdata($data);
                                                            $session = new Zend_Session_Namespace('System');
                                                            if($result == "success"){
                                                                           $alerthead = "OTD System Message - High MHR ";
                                                                           $alertcontent = "This athlete seems to have MHR outside the healthy range (40 - 90)<br/>
                                                                                          <br/>
                                                                                          MHR: ".$data["mhr"]."";
                                                                           $alertlevel = 1;
                                                                           $athleteid = $this->user->userid;
                                                                           $smail = true;
                                                                           $alerts = new Application_Model_DbTable_Alerts();
                                                                           $alerts->doAlert($alerthead,$alertcontent, $alertlevel,$athleteid,$smail);

                                                                           $session->msg = "Successfully saved your report.
                                                                                          You have finished completing todays training information, thank you!<br/>
                                                                                          if you have any injury and or niggle, you must report them
                                                                                          using the link below";
                                                                           $session->redir = "/athlete/injuries";
                                                                           $session->redirtext = "Take me to injuries & niggles report form";
                                                                           $this->_helper->redirector('index','message');
                                                            }

                                             }
                                             else{
                                                            $this->view->form->populate($data);
                                             }
                              }
               }

               function myprogressAction(){
                              $this->view->headTitle('My Progress');
                               $this->view->headLink()->appendStylesheet('/css/graph.css');
                              $this->view->images = array();

                              $this->view->userid = $this->user->userid;
                              $this->view->images[] = '/drawchart.php?userid='.$this->user->userid;
                              $this->view->images[] = '/drawchart_average.php?userid='.$this->user->userid;
                              $this->view->images[] = '/drawchart_geninfo.php?userid='.$this->user->userid .'&sq=1&mr=1&pr=1&pte=1&ms=1&gf=1';
               }

               function illnessAction(){
                              $wr = new Application_Model_DbTable_WeeklyReport();
                              $result = $wr->alreadyDoneThisWeek($this->user->userid);
                              if($result == true){
                                             $session = new Zend_Session_Namespace("System");
                                             $session->msg = "You have already completed this week's illness report. Please proceed to daily report";
                                             $session->redir = "/athlete/dailyreport";
                                             $session->redirtext = "Take me to daily report form.";
                                             $this->_helper->redirector("index", "message");
                              }
                              $this->view->headLink()->appendStylesheet('/css/weeklyreport.css');
                              $illtypes = new Application_Model_DbTable_Illnesstype();
                              $this->view->illtypes = $illtypes->fetchAll();
                              $this->view->userid = $this->user->userid;
                              $this->view->thisweekstartdate = date("Y-m-d", strtotime(date("Y",time())  . "W"  . date("W",time())));
                              $this->view->lastweekstartdate = date("Y-m-d", strtotime(date("Y",time())  . "W"  . date("W",time())) - 604800);
               }

               function addweeklyformAction(){
                              $this->_helper->layout->disableLayout();
                              $this->_helper->viewRenderer->setNoRender(true);
                              $wr = new Application_Model_DbTable_WeeklyReport();
                              $wrr = new Application_Model_DbTable_WeeklyReportRatio();
                              if($this->getRequest()->isPost()){
                                             $data = $this->getRequest()->getPost();
                                             try{
                                                            $wrrdata = array(
                                                                "userid" => $this->user->userid,
                                                                "date" => $data["thisweek"],
                                                                "max_snatch" => $data["snatch"],
                                                                "max_cj" => $data["pcj"],
                                                                "bw" => $data["bw"]
                                                            );
                                                            $wrr->insert($wrrdata);

                                                            $illdays = 0;
                                                            if($data["ill"]){
                                                            $illlist = explode(",",$data["ill"]);
                                                            $alert = "";
                                                            $alertlevel = 1;
                                                            $illtype = new Application_Model_DbTable_Illnesstype();
                                                           
                                                                          foreach( $illlist as $illness){
                                                                                         $explosion = explode("x",$illness);
                                                                                         $illnessname = $illtype->fetchRow("id = ".$explosion[0]);
                                                                                         $alert .= '<i>Illness</i> : '. $illnessname["name"] . ' - '. $explosion[2] . "days
                                                                                                         (".$explosion[1] . ")<br/>" ;
                                                                                         $wrdata = array(
                                                                                            "date" => $data["lastweek"],
                                                                                             "userid" => $this->user->userid,
                                                                                             "illnesstypeid" => $explosion[0],
                                                                                             "severity" => $explosion[1],
                                                                                             "duration" => $explosion[2],
                                                                                             "activity_level" => $explosion[3]
                                                                                         );
                                                                                         $illdays += (int) $explosion[2];
                                                                                         $wr->insert($wrdata);

                                                                          }
                                                            }
                                                           if($alert != ""){
                                                                           $alerts = new Application_Model_DbTable_Alerts();
                                                                           $alerts->doAlert("New Illness reported", $alert, $alertlevel, $this->user->userid,true);
                                                           }
                                                            $msg = "All data has been recorded. You had ". $illdays . " ill day(s)";
                                                            $session = new Zend_Session_Namespace('System');
                                                             $session->msg = $msg;
                                                             $session->redir = "/athlete/dailyreport";
                                                             $session->redirtext = "Proceed to next step (Daily report)";
                                                             echo "success";
                                             }
                                             catch(Exception $e){
                                                            $msg = $e->getMessage();
                                                            $session = new Zend_Session_Namespace('System');
                                                            $session->msg = $msg;
                                                            echo $msg;//" Failed to save data. You may have entered the data for this week already.";
                                             }

                                             
                              }

               }
               function injuriesAction(){
                              $this->view->headLink()->appendStylesheet('/css/injuries.css');
               }

               function historyAction(){
                              $wr = new Application_Model_DbTable_WeeklyReport();
                              $id = $this->user->userid;
                              $this->view->illnesslist = $wr->getUserReport($id);
                              $this->view->illnesstype = $wr->getIllnessTypes();

                              $inj = new Application_Model_DbTable_Injuries();
                              $this->view->injurylist = $inj->getinjuries($id);
               }
               function saveinjuriesAction(){
                              $this->_helper->layout->disableLayout();
                              $this->_helper->viewRenderer->setNoRender(true);
                              if($this->getRequest()->isPost()){
                                             $data = $this->getRequest()->getPost();
                                             $date = $data["date"];
                                             $indata = trim($data["data"], "[");
                                             $indata = trim($indata, "]");
                                             $injuries = explode("][", $indata);
                                             //Zend_Debug::dump($date);
                                             //Zend_Debug::dump($injuries);
                                             $injuryreport = new Application_Model_DbTable_Injuriesreport();
                                             $injuryentry = new Application_Model_DbTable_Injuriesentry();
                                             try{
                                                            $injuryreport->insertnewreportrow(array(
                                                                "date" => $date,
                                                                "userid" => $this->user->userid
                                                            ));

                                                            $reportrow = $injuryreport->fetchRow("`date` = '".$date."' and `userid` = '".$this->user->userid."'");
                                                            $reportid = $reportrow["reportid"];

                                                            $alert = "";
                                                            $alertlevel = array();

                                                            foreach($injuries as $injury){
                                                                           $realdata = explode("***", $injury);
                                                                           if((int) $realdata[4] == 1){
                                                                                          $alert .= '<i>New Injury</i>: '.$realdata[1].' (pain rating:'.$realdata[2].')<br/>';
                                                                           }

                                                                           if($realdata[5] == "c" || $realdata[5] == "d"){
                                                                                          $alertlevel[] = 2;
                                                                                          $alert .= '<i>Training modified</i>: '.$realdata[1].' (pain rating:'.$realdata[2].') Type '.$realdata[5].'
                                                                                                         (unable to complete prescribed exercise or unable to train.)<br/>';
                                                                           }
                                                                           
                                                                           $injuryentry->insert(array(
                                                                               "reportid" => $reportid,
                                                                               "inj_or_nig" => $realdata[0],
                                                                               "muscle_group" => $realdata[1],
                                                                               "pain_rating" => $realdata[2],
                                                                               "tissue" => $realdata[3],
                                                                               "type" => $realdata[4],
                                                                               "training_modified" => $realdata[5],
                                                                               "other_info" =>  $realdata[6],
                                                                           ));

                                                                           

                                                            }
                                                            if($alert != ""){ //if there are alert data
                                                                           $alert = "<h3>This is an auto alert generated by an athlete's input</h3><br/><br/>".$alert;
                                                                                          $alerthead = "Injuries & Niggle alerts";
                                                                                          $alerts = new Application_Model_DbTable_Alerts();
                                                                                          $alerts->doAlert($alerthead, $alert, $alertlevel,$this->user->userid,true);
                                                                           }
                                                            $session = new Zend_Session_Namespace('System');
                                                            $session->msg = "Successfully saved injuries/niggles infor for " . $date. "<br/>
                                                                           You have reported " . count($injuries) . " injuries/niggles in total.";
                                                            echo "success";


                                             }
                                             catch(SQLException $e){
                                                            $session = new Zend_Session_Namespace('System');
                                                            $session->msg = $e->getMessage();
                                                            echo "failed";
                                             }
                              }
               }
               function profileAction(){
                              $this->view->email = $this->user->email;
               }

               function saveemailAction(){
                    $this->_helper->layout->disableLayout();
                    $this->_helper->viewRenderer->setNoRender(true);
                    if($this->getRequest()->isPost()){
                                   $data = $this->getRequest()->getPost();
                                   $emailval = new Zend_Validate_EmailAddress();
                                   if($emailval->isValid($data["email"])){
                                                  $user = new Application_Model_DbTable_User();
                                                  $user->update($data,"userid = ".$this->user->userid);
                                                  echo "New email saved! Please logout and login again to see the change.";

                                   }
                                   else{
                                                  echo "Invalid email address!";
                                   }
                    }
     }
}

?>
