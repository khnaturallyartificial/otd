<?php
class CoachController extends Zend_Controller_Action{
               public $coachid = null;
               protected $coach = null;
    function init(){
	$auth = Zend_Auth::getInstance();
        if($auth->hasIdentity()){
	    $user = $auth->getIdentity();
	   if($user->role != "C"){
	    $this->_helper->redirector('index','index');
	    }
                        else{
                                       $this->coachid = $user->userid;
                                       $this->coach = $user;
                        }

	}
                    else{
                                   $this->_helper->redirector('index','index');
                    }
	$this->view->headScript()->appendFile('http://ajax.googleapis.com/ajax/libs/jquery/1.4.2/jquery.min.js');
                    $this->view->headScript()->appendFile('http://ajax.googleapis.com/ajax/libs/jqueryui/1.8.2/jquery-ui.min.js');
	$this->view->headScript()->appendFile('/js/roundcorner.js');
	$this->view->headScript()->appendFile('/js/script.js');
                    $this->view->headLink()->appendStylesheet('/css/jqueryUI.css');
	$this->view->headScript()->appendFile('/js/coach.js');
	$this->view->menu = Application_Model_DbTable_Coach::makeCoachMenu();
	
    }
    
    function indexAction(){
	$this->view->headTitle('Dashboard [Coach]');
                    $plan = new Application_Model_DbTable_Plan();
                    $cav = new Application_Model_DbTable_Coachathleteview();
                    $this->view->plancount = $plan->countPlans($this->coachid);
                    $this->view->athletecount = $cav->countAthleteUnderCoach($this->coachid);
	
    }

    function deleteexerciseplanAction(){
                   $this->_helper->layout->disableLayout();
                                  $this->_helper->viewRenderer->setNoRender(true);
                   if($this->getRequest()->isPost()){
                                  $data = $this->getRequest()->getPost();
                                  $deleteid = $data["deleteid"];
                                  $exerciseplans = new Application_Model_DbTable_Exerciseplan();
                                  try{
                                                 $exerciseplans->delete('exerciseplanid = '.$deleteid);
                                                 echo "Exercise has been deleted"; //must always contain the word deleted
                                  }
                                  catch(Exeption $e){
                                                 echo "Failed to delete exerciseplan"; //must never have the word deleted
                                  }

                   }
    }

    function addexerciseplanAction(){
                   $this->_helper->layout->disableLayout();
                                  $this->_helper->viewRenderer->setNoRender(true);
                   if($this->getRequest()->isPost()){
                                  $data = $this->getRequest()->getPost();
                                  $form = new Application_Form_Exerciseplan();
                                  if($form->isValid($data)){
                                               $exerciseplan = new Application_Model_DbTable_Exerciseplan();
                                               try{
                                                              $exerciseplan->insert($data);
                                                              $epid = $exerciseplan->fetchAll($exerciseplan->select()->from("exerciseplan",array('exerciseplanid'))
                                                                      ->order('exerciseplanid DESC')->limit(1));
                                                              $epid = $epid[0]["exerciseplanid"];
                                                               echo $epid."||success||<img src=\"/img/thumbup.png\" alt=\"\" /> Successfully added to the plan.";
                                               }
                                               catch(Exception $e){
                                                              echo '<img src="/img/thumbdown.png" alt="" /> Failed to add plan';
                                               }

                                  }
                                  else{
                                                echo 'x||failed||<img src="/img/thumbdown.png" alt="" /> An error has occured. Please make sure that weight, repititions and sets
                                                               must all be numbers.';
                                  }
                   }
    }

    function createplanAction(){
                   $this->view->headTitle('Create a new plan');
                   $this->view->form = new Application_Form_Newplan();

                   if($this->getRequest()->isPost()){
                                  $data = $this->getRequest()->getPost();
                                  if($this->view->form->isValid($data)){
                                                 $plans = new Application_Model_DbTable_Plan();
                                                 unset($data["submit"]);
                                                 $sd = strtotime($data["startdate"]);
                                                 $ed = strtotime($data["enddate"]);
                                                 $data["duration"] = ($ed - $sd + 86400) / 86400;
                                                 unset($data["enddate"]);
                                                 unset($data["planid"]);
                                                 $session = new Zend_Session_Namespace('System');
                                                 if($plans->addPlan($data)){
                                                                $session->msg = "Plan `".$data['planname']."` has been added.";
                                                                $session->bot = "happy";
                                                 }
                                                 else{
                                                                $session->msg = "Failed to add plan. Probably because a plan of
                                                                               the same name already exist, please try again.";
                                                                $session->bot = "sad";
                                                 }
                                                 $this->_helper->redirector('index','message');
                                  }
                                  else{
                                                 $this->view->form->populate($data);
                                  }
                   }
    }
    
    function exerciseAction(){
	$this->view->headTitle(' Exercise types');
                    $exercises = new Application_Model_DbTable_Exercise();
                    $this->view->exerciselist = $exercises->makeExerciseList();
                     if($this->getRequest()->isPost()){
                                   $this->_helper->layout->disableLayout();
                                  $this->_helper->viewRenderer->setNoRender(true);
                                  $data = $this->getRequest()->getPost();
                                  if($data["e"]){
                                                 $result =  $exercises->addExercise($data["e"]);
                                                 echo $result;
                                  }
                                  elseif($data["newexerciselist"]){
                                                 echo $this->view->exerciselist;
                                  }
                                  
                   }
    }

    function plansAction(){
                   $this->view->headTitle('Plans');
                   

                   if($this->getRequest()->getParam('planid')){
                                  $this->view->planid = $this->getRequest()->getParam('planid');
                                  $cav = new Application_Model_DbTable_Coachathleteview();
                                  $this->view->athleteselection = '<select id="athleteselection" name="athleteselection">'.
                                          $cav->makeAthleteSelect($this->coachid, $this->getRequest()->getParam('planid'))
                                                  .'</select>';
                                  $plans = new Application_Model_DbTable_Plan();
                                  $exerciseplans = new Application_Model_DbTable_Exerciseplan();
                                  $this->view->exerciseplans = $exerciseplans->getExercisePlans($this->getRequest()->getParam('planid'));
                                  $this->view->form = new Application_Form_Newplan();
                                  $form2 = new Application_Form_Exerciseplan();
                                  $form2->planid->setValue($this->getRequest()->getParam('planid'));
                                  $exercise = new Application_Model_DbTable_Exercise();
                                  $form2->date->addMultiOptions(
                                                  $plans->makeDateSelection($this->getRequest()->getParam('planid'))
                                                          );
                                  $form2->exerciseid->addMultiOptions(
                                          $exercise->makeExerciseSelection());

                                  $planid = $this->getRequest()->getParam("planid");
                                   $cav = new Application_Model_DbTable_Coachathleteview();
                                   $ret = "<ul>";
                                   $list = $cav->listAthletes($this->coachid, $planid);
                                   foreach($list as $at){
                                                  $ret .= '<li id="at'.$at["athleteid"].'">'.$at["name"].' '.$at["surname"].'  <img src="/img/cross.png" class="removeathfrmlst" alt="" /></li>';
                                   }
                                   $ret .= '</ul>';
                                   $this->view->athletelist = $ret;




                                  $this->view->addexerciseform = $form2;
                                  $plandata = new Application_Model_DbTable_Plan();
                                  $data = $plandata->getPlan($this->getRequest()->getParam('planid'));
                                  $session = new Zend_Session_Namespace('System');
                                  $sd = strtotime($data["startdate"]);
                                  $et = $data["duration"]*86400;
                                  $data["enddate"] = date("Y-m-d",($sd + $et - 86400));
                                  unset($data["duration"]);
                                  unset($data["creator"]);
                                  if($data == null){
                                                 $session->msg = 'Failed to get plan information. Either the plan does not exist,
                                                                or you are not the creator of this form.';
                                                 $session->bot = 'sad';
                                                 $this->_helper->redirector('index','message');
                                  }
                                  $this->view->form->populate($data);
                   }
    }

    function updateplanAction(){
                   $this->_helper->layout->disableLayout();
                   $this->_helper->viewRenderer->setNoRender(true);
                   if($this->getRequest()->isPost()){
                                  $plans = new Application_Model_DbTable_Plan();
                                  $data = $this->getRequest()->getPost();
                                  if($data["getplanlist"]){
                                                 echo  $plans->getPlans("id");
                                                 exit;
                                  }
                                  $form = new Application_Form_Newplan();
                                  if($form->isValid($data)){
                                                 $sd = strtotime($data["startdate"]);
                                                 $ed = strtotime($data["enddate"]);
                                                 $data["duration"] = ($ed-$sd+86400)/86400;
                                                 unset($data["enddate"]);
                                                 if($plans->update($data, "planid = ".$data["planid"])){
                                                                echo "Plans info successfully changed.";
                                                 }
                                                 else{
                                                                echo "Failed to change plan info.";
                                                 }
                                  }
                   }
    }

    function planathletelistAction(){
                   $this->_helper->layout->disableLayout();
                   $this->_helper->viewRenderer->setNoRender(true);
                   $planid = $this->getRequest()->getParam("planid");
                    $cav = new Application_Model_DbTable_Coachathleteview();
                    $ret = "<ul>";
                    $list = $cav->listAthletes($this->coachid, $planid);
                    foreach($list as $at){
                                   $ret .= '<li id="at'.$at["athleteid"].'">'.$at["name"].' '.$at["surname"].' <img src="/img/cross.png" class="removeathfrmlst" alt="" /></li>';
                    }
                    $ret .= '</ul>';
                    echo $ret;

    }
    function attachathleteAction(){
                   $this->_helper->layout->disableLayout();
                   $this->_helper->viewRenderer->setNoRender(true);
                   if($this->getRequest()->isPost()){
                                  try{
                                                 $adata = $this->getRequest()->getPost();
                                                 $data = array("planid"=>$adata["plan"]);
                                                 $where = "athleteid = ".$adata["ath"];
                                                 $cav = new Application_Model_DbTable_Coachathleteview();
                                                 $cav->update($data, $where);
                                                 echo "success";
                                  }
                                  catch(Exception $e){
                                                 echo $e->getMessage();
                                  }
                   }
    }

    function detachathleteAction(){
                   if($this->getRequest()->isPost()){
                                  $adata = $this->getRequest()->getPost();
                                  $data = array("planid" => 0);
                                  $where = "athleteid = ".$adata["aid"];
                                  $cav = new Application_Model_DbTable_Coachathleteview();
                                  $cav->update($data, $where);
                                  $this->_helper->layout->disableLayout();
                   $this->_helper->viewRenderer->setNoRender(true);
                   }
    }

    function viewathAction(){
                   $this->view->headTitle("Athletes");
                   $cav = new Application_Model_DbTable_Coachathleteview();
                   $this->view->athletelist = $cav->getAthleteUnderCoach($this->coachid);
                   $this->view->ua = $cav->getUnassignedAthlete();
    }

    function doattachAction(){
                                   $this->_helper->layout->disableLayout();
                                  $this->_helper->viewRenderer->setNoRender(true);
                                   if($this->getRequest()->isPost()){
                                                  $data = $this->getRequest()->getPost();
                                                  $sp = new Application_Model_Super();

                                                  if($sp->attachathletetocoach($data["aid"], $this->coachid)){
                                                                 echo "success";
                                                  }
                                                  else{
                                                                 echo "failed";
                                                  }
                                   }
                    }
     function monitorAction(){
                    $this->view->headTitle("Monitor Athletes");
                    $this->view->headLink()->appendStylesheet('/css/graph.css');
                    $cav = new Application_Model_DbTable_Coachathleteview();
                    $this->view->athletes = $cav->getAthleteUnderCoach($this->coachid);
     }

     function detachfrommeAction(){
         if($this->getRequest()->isPost()){
             $data =$this->getRequest()->getPost();
             $ca = new Application_Model_DbTable_CoachAthlete();

             if($ca->detachfromcoach($data["aid"])){
                 return "success";
             }
             else{
                 return"failed";
             }
         }
     }


     function athsumAction(){
                    $this->view->headTitle("Athlete Summary");
                    $this->view->headLink()->appendStylesheet('/css/athsum.css');
                    $cav = new Application_Model_DbTable_Coachathleteview();
                    $this->view->athletes = $cav->getAthleteUnderCoach($this->coachid);
                    $this->view->form = new Application_Form_Uploadfile();

                    if($this->getRequest()->isPost()){
                                $data = $this->getRequest()->getPost();
                                //print getcwd();
                                $session = new Zend_Session_Namespace('System');
                                if($this->view->form->isValid($data)){
                                               $upload = new Zend_File_Transfer_Adapter_Http();
                                               $upload->setDestination("userpicture");
                                               try{
                                                              $upload->receive();
                                               }
                                               catch(Zend_File_Transfer_Exception $e){
                                                              $e->getMessage();
                                               }

                                               $uploadedData = $this->view->form->getValues();
                                               Zend_Debug::dump($uploadedData, 'Form Data: ');

                                               $name = $upload->getFileName('file_path');
                                               $upload->setOptions(array('useByteString' => false));
                                               $size = $upload->getFileSize('file_path');
                                               $mimeType = $upload->getMimeType('file_path');

                                               print "name: ". $name;
                                               print "File size: " . $size;

                                               $renamefile = time() . '.jpg';
                                               $fullrenamepath = 'userpicture/'.$renamefile;

                                               $filterFileRename = new Zend_Filter_File_Rename(array('target'=> $fullrenamepath, 'overwrite' => true));
                                               $filterFileRename->filter($name);

                                               $session->msg = "Image saved. [Size: ".round ((int) $size / 1024) . " KB.]";

                                               $usr = new Application_Model_DbTable_User();
                                               try{
                                                              $dataa = array(
                                                                  "picture" => $renamefile
                                                              );
                                                              $usr->update($dataa, "userid = '". $data["useridh"]."'");
                                               }
                                               catch(Exception $e){
                                                              echo $e->getMessage();
                                                              $session->msg = "Error Inserting data into the database...";
                                               }
                                               $this->_helper->redirector('index','Message');
                                }

                    }
     }

     function fetchathleterowAction(){
                    $this->_helper->layout->disableLayout();
                    $this->_helper->viewRenderer->setNoRender(true);
                    if($this->getRequest()->isPost()){
                                   $data = $this->getRequest()->getPost();
                                   $users = new Application_Model_DbTable_User();
                                   $user = $users->fetchRow("userid = ".$data["aid"]);
                                   $dailyreports = new Application_Model_DbTable_Dailyreport();
                                   $mepv = new Application_Model_DbTable_Markedexerciseplanview();
                                   $dailyreport = $dailyreports->fetchAllForUser($data["aid"]);
                                   $recentcomment = " ";
                                   $latestweight = 0;
                                             foreach($dailyreport as $d){
                                                            $recentcomment = ($d["comment"]) ?  $d["date"]." &raquo; ".$d["comment"] . "<br/>" . $recentcomment : $recentcomment;
                                                            $latestweight = $d["bw_morning"];
                                             }
                                   
                                   $dobarray = explode("-",$user["date_of_birth"]);
                                   $dobtimestamp = mktime(0,0,0,$dobarray[1],$dobarray[2],$dobarray[0]);
                                   $agestamp = time() - $dobtimestamp;
                                   $age = floor($agestamp / 31556926);

                                   $inj = new Application_Model_DbTable_Injuries();
                                   $injcount = $inj->countinjuries($data["aid"]);

                                   $statustoday = $inj->getTrafficLightCurrent($data["aid"]);
                                   $amberandred = $inj->getInjuries30days($data["aid"]);

                                   echo $user["name"] . " " . $user["surname"] . "||" . $age . "|| ||" . date("j M Y",time())
                                             . "||" . $user["height"] . "||" . $latestweight . "||" . $recentcomment . "||" . $user["current_max_snatch"]
                                              . "||" . $user["current_max_cj"]. "||" . $user["body_fat"];
                                 $percent =  $mepv->getAvLoadRepsPercent30days($data["aid"]);
                                 echo '||'.$percent[0].'||'.$percent[1].'||'.$user["picture"] . '||'.$injcount.'||'.$statustoday
                                 .'||'.$amberandred[0].'||'.$amberandred[1];
                                   
                    }
     }

     function historyAction(){
                    $cav = new Application_Model_DbTable_Coachathleteview();
                    $this->view->athletelist = $cav->getAthleteUnderCoach($this->coachid);
                    
                    if($this->getRequest()->getParam("atid")){
                              $wr = new Application_Model_DbTable_WeeklyReport();
                              $id = $this->getRequest()->getParam("atid");
                              $users = new Application_Model_DbTable_User();
                              $user = $users->fetchRow("userid = ".$id);
                              $this->view->username = $user["name"]." ".$user["surname"];
                              $this->view->illnesslist = $wr->getUserReport($id);
                              $this->view->illnesstype = $wr->getIllnessTypes();

                              $inj = new Application_Model_DbTable_Injuries();
                              $this->view->injurylist = $inj->getinjuries($id);
                    }
     }

     function updateathsumAction(){
                    $this->_helper->layout->disableLayout();
                    $this->_helper->viewRenderer->setNoRender(true);
                    if($this->getRequest()->isPost()){
                                   $data = $this->getRequest()->getPost();
                                 
                                   $updatedata = array(
                                     "current_max_snatch"  => (int) $data["maxsnatch"],
                                     "current_max_cj" => (int) $data["maxcj"],
                                       "body_fat" => (int) $data["bf"]
                                   );
                                   $user = new Application_Model_DbTable_User();
                                   try{
                                                  $user->update($updatedata, "userid = ".(int) $data["aid"]);
                                                  echo "success";
                                   }
                                   catch(SQLException $e){
                                                  echo "failed";
                                   }

                    }
     }

     function profileAction(){
                    $this->view->coachemail = $this->coach->email;
     }
     function saveemailAction(){
                    $this->_helper->layout->disableLayout();
                    $this->_helper->viewRenderer->setNoRender(true);
                    if($this->getRequest()->isPost()){
                                   $data = $this->getRequest()->getPost();
                                   $emailval = new Zend_Validate_EmailAddress();
                                   if($emailval->isValid($data["email"])){
                                                  $user = new Application_Model_DbTable_User();
                                                  $user->update($data,"userid = ".$this->coachid);
                                                  echo "New email saved! Please logout and login again to see the change.";

                                   }
                                   else{
                                                  echo "Invalid email address!";
                                   }
                    }
     }

     function alertAction(){
                    $cav = new Application_Model_DbTable_Coachathleteview();
                    $athlist = $cav->fetchAll("coachid = ".$this->coachid);
                    $alert = new Application_Model_DbTable_Alerts();
                    $retdata = array();
                    foreach($athlist as $athlete){
                                   $id = $athlete["athleteid"];
                                   $name = $athlete["name"] . " " . $athlete["surname"];
                                   $arraytoadd = array();
                                   $alertsforthisath = $alert->fetchAll($alert->select()->where("athleteid = ".$id)->limit(5));
                                   foreach($alertsforthisath as $afts){
                                                  $arraytoadd[] = array("date"=>$afts["date"], "alerthead"=>$afts["alerthead"], "alertcontent" => 
                                                      str_replace("<h3>This is an auto alert generated by an athlete's input</h3><br/><br/>","",$afts["alertcontent"]));
                                   }
                                   $retdata[]= array("name"=> $name, "data" => $arraytoadd);
                    }
                    $this->view->alertdata = $retdata;
     }

}
?>