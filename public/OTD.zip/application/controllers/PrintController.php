<?php

class PrintController extends Zend_Controller_Action {
               function printplanAction(){
                   $this->_helper->layout->disableLayout();
                   $this->_helper->viewRenderer->setNoRender(true);
                   $misc = new Application_Model_Misc();
                   $plans = new Application_Model_DbTable_Plan();
                   $lul = $misc->selectexercisesByPlanId($this->getRequest()->getParam("planid"));
                   $plan = $plans->getPlan($this->getRequest()->getParam("planid"));


                   echo '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
                                  <html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
                                  <head>
                                  <meta http-equiv="Content-Type" content="text/html;charset=utf-8" />
                                  <title>Print Plan</title>
                                  <style>
                                                            body{
                                                                           font-family: \'Trebuchet MS\', sans-serif;
                                                                           font-style:italic;
                                                                           font-size:12px;
                                                            }

                                                            .date{
                                                                           font-weight: bold;
                                                            }


                                                            .exid{
                                                                           font-weight: bold;
                                                                           font-size: 17px;
                                                                           color:#000000;
                                                                            border-right:4px solid;
                                                            }

                                                            table{
                                                                           border:2px solid #6b6b6b;
                                                                           width:100%;
                                                                           table-layout: fixed;
                                                                           border-collapse: collapse;
                                                                           margin-bottom:5px;
                                                            }

                                                            td{
                                                                           background-color: #f5f5f5;
                                                                           margin:0px;
                                                                           color:#454545;
                                                                           text-align: center;
                                                                           border-right: 1px solid #858585;
                                                                           border-bottom: 1px solid #858585;
                                                                           line-height:10px;
                                                                           padding:4px;
                                                            }


                                                            h2{
                                                                           border-bottom: 1px dotted #545454;
                                                            }
                                                            .red{
                                                                           color:#e44115;
                                                                           font-size:15px;
                                                            }
                                                            table#commentbox, #commentbox tr, #commentbox td{
                                                                           border:none;
                                                                           background:none;
                                                                           text-align:left;
                                                                           padding: 2px;
                                                            }
                                                            #commentbox{
                                                                           margin:5px;
                                                                           border:1px solid #c8c8c8 !important;
                                                                           padding:5px;
                                                                           height:40px;
                                                                           color:#585858;
                                                                           margin-bottom: 10px;
                                                                           line-height: 10px;
                                                                           vertical-align:top;
                                                              }

                                  </style>
                                  </head>
                                  <body>';
                   echo '<img src="http://otd.naturallyartificial.net/img/smallwcl.gif" alt="" style="float:right;"/>
                                  <h2>Plan: '.str_replace("\\","",$plan["planname"]).'</h2>';
                   echo' <span class="red">Please fill empty boxes with the applied KGs or strikethrough which were not done.</span>
                                  ';
                   $exerciselist = new Application_Model_DbTable_Exercise();
                   $exlist = $exerciselist->fetchAll();
                   $exercisearray = array();

                   foreach($exlist as $exl){
                                  $exercisearray[$exl["exerciseid"]] = $exl["exercisename"];
                   }
                   unset($exerciselist, $exlist);

                   //dividing them into days
                   $days = array();
                   $startdate = $lul[0]["date"];
                   $firstindex = 0;
                   $cellsperrow = 14;
                   foreach($lul as $l){
                                  if($l["date"] != $startdate){
                                                 $firstindex++;
                                                 $startdate = $l["date"];
                                  }
                                  $days[$firstindex][] = $l;

                   }

                   //now they are divided into days
                   //for each day, we want a table
                   echo '<div id="print">';
                   foreach($days as $day){
                              $commentblock = "";
                                  echo '<div class="date">&raquo; '.date("l d-M-Y", strtotime($day[0]["date"])).'</div>';
                                  echo '<table>
                                                 ';
                                  $exid = 0;
                                 $count = 0;
                                 $cells = 0;
                                foreach($day as $d){
                                                
                                               if($d["exerciseid"] != $exid){
                                                              $exid = $d["exerciseid"];
                                                              if($count == 0){
                                                              echo '<tr><td class="exid">'.$d["exerciseid"].'</td>
                                                                                            ';
                                                              $count += 1;
                                                              }
                                                              else{
                                                                             if($cellsperrow > $cells){
                                                                                            for($ii=0;$ii < ($cellsperrow - $cells); $ii++){
                                                                                                           echo '<td></td>';
                                                                                            }
                                                                                            $cells = 0;
                                                                             }
                                                                               echo '</tr><tr><td class="exid">'.$d["exerciseid"].'</td>
                                                                                              ';
                                                              }
                                               }
                                               //normal mode
                                             /*echo '<td>'.$d["weight"].'/'.$d["reps"].'/'.$d["sets"].'</td>
                                                              ';
                                                             $cells++;
                                              */
                                               //or separated mode
                                               for($i=0;$i<$d["sets"];$i++){
                                                              echo '<td>'.$d["weight"].'/'.$d["reps"].'<br/></td>
                                                            ';
                                                              if($d["comment"]){
                                                                             $str = 'for ' . $exercisearray[$d["exerciseid"]] . ' ('.$d["weight"].'/'.$d["reps"].') - ';
                                                                             if(stristr($commentblock, $str) == false){
                                                                                          $commentblock  .= $str . str_replace("\\","",$d["comment"]) . '<br/>';
                                                                             }
                                                              }
                                                              $cells++;
                                               }
                                               //end modes
                                               
                                }
                                if($cellsperrow > $cells){
                                                                                            for($ii=0;$ii < ($cellsperrow - $cells); $ii++){
                                                                                                           echo '<td></td>';
                                                                                            }
                                                                                            $cells = 0;
                                                                             }
                                
                                echo '</tr>
                                               </table>
                                                            <table id="commentbox">
                                                                           <tr>
                                                                                          <td style="width:200px;">
                                                                                                         Body weight: _______kg.<br/>
                                                                                                         Notes:
                                                                                          </td>
                                                                                          <td style="width:240px;">
                                                                                          Exercise intensity rating 0 - 10:_____<br/>
                                                                                          <span style="font-size:8px;">Please record within 30 min of finishing training)</span>
                                                                                          </td>
                                                                                          <td>
                                                                                          Coach Notes:
                                                                                          </td>
                                                                           </tr>
                                                                           <tr>
                                                                                           <td>
                                                                                          </td>
                                                                                          <td>
                                                                                          </td>
                                                                                          <td>
                                                                                          <span class="commentblock">'.$commentblock.'</span>
                                                                                          </td>
                                                                           </tr>
                                                            </table>
                                                           
                                             ';
                   }
                   echo '</div></body></html>';
               }
}

?>
