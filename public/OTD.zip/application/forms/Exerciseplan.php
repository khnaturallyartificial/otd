<?php

class Application_Form_Exerciseplan extends Zend_Form{
               function  __construct($options = null) {
                              parent::__construct($options);

                              $planid = new Zend_Form_Element_Hidden('planid');
                              $planid->setRequired(true);

                              $html = array('HtmlTag',array('tag'=>'br', 'openOnly'=>true));

                              $date = new Zend_Form_Element_Select('date');
                              $date->setLabel('Date: ')->setDecorators(array('ViewHelper',$html,'Label'))->setRequired(true)
                                      ->setRegisterInArrayValidator(false);

                              $exerciseid = new Zend_Form_Element_Select('exerciseid');
                              $exerciseid->setRequired(true)->setDecorators(array('ViewHelper',$html,'Label'))->setLabel('Exercise type: ')
                                      ->setRegisterInArrayValidator(false);

                              $validator_int = new Zend_Validate_Int();

                              $weight = new Zend_Form_Element_Text('weight');
                              $weight->setLabel('Weight: (in kg.)')->setDecorators(array('ViewHelper',$html,'Label'))->addValidator($validator_int)
                                      ->setRequired(true);

                              $reps = new Zend_Form_Element_Text('reps');
                              $reps->setLabel('Repititions: ')->setDecorators(array('ViewHelper',$html,'Label'))->addValidator($validator_int)
                                      ->setRequired(true);

                              $sets = new Zend_Form_Element_Text('sets');
                              $sets->setLabel('Sets: ')->setDecorators(array('ViewHelper',$html,'Label'))->addValidator($validator_int)->setRequired(true);

                              $comment = new Zend_Form_Element_Text('comment');
                              $comment->setLabel("Comment: ")->setDecorators(array('ViewHelper',$html,'Label'))->setRequired(false);

                              $this->addElements(array($planid,$date,$exerciseid,$weight,$reps,$sets,$comment));
               }
}

?>
