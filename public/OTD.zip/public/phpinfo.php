<?php
//phpinfo();
echo "aj ssdrg22sd rtdkfj asdf";
?>
